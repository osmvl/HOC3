package hoc3;

public enum EnumTipoSymbol {//
    VAR, UNDEF, BLTIN, CONST_PREDEF;
}
