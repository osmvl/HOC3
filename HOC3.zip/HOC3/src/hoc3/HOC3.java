package hoc3;

public class HOC3 {

    public static void main(String[] args) {
        HOC3Vista interfaz = new HOC3Vista();
        interfaz.setVisible(true);
    }
}