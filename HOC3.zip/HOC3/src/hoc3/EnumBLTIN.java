package hoc3;
//Valores constantes asociados a cada una de las funciones
public enum EnumBLTIN {
    SIN, COS, ATAN, LOG, LOG10, EXP, SQRT, INT, ABS;
}
